using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ShoppingCart.Data;
using ShoppingCart.Model;

namespace ShoppingCart.Pages
{
    public class FashionProductsModel : PageModel
    {
        private readonly FashionProductModel _fashionProductModel;

        public List<Product> Products { get; set; }

        public FashionProductsModel()
        {
            _fashionProductModel = new FashionProductModel();
        }

        public void OnGet()
        {
            Products = _fashionProductModel.GetProducts();
        }
    }
}
