using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ShoppingCart.Pages
{
    public class HomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
