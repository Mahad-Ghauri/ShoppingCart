using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ShoppingCart.Data;
using ShoppingCart.Model;

namespace ShoppingCart.Pages
{
    public class GroceryProductsModel : PageModel
    {
        private readonly GroceryProductModel _groceryProductModel;

        public List<Product> Products { get; set; }

        public GroceryProductsModel()
        {
            _groceryProductModel = new GroceryProductModel();
        }

        public void OnGet()
        {
            Products = _groceryProductModel.GetProducts();
        }
    }
}
