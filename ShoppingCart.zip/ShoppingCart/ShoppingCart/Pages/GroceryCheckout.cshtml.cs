using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ShoppingCart.Model; // Ensure you have the appropriate namespace for your Item model
using ShoppingCart.Service; // Ensure you have the appropriate namespace for your session service
using System.Collections.Generic;

namespace ShoppingCart.Pages
{
    public class GroceryCheckoutModel : PageModel
    {
        public List<Item> Cart { get; set; } // Property for the shopping cart

        [BindProperty]
        public string Name { get; set; } // User's name

        [BindProperty]
        public string Address { get; set; } // User's address

        [BindProperty]
        public string PaymentMethod { get; set; } // Selected payment method

        public IActionResult OnGet()
        {
            // Retrieve the cart from the session
            Cart = SessionService.GetSessionObjectFromJson<List<Item>>(HttpContext.Session, "cart");

            // Check if the cart is empty
            if (Cart == null || Cart.Count == 0)
            {
                TempData["Error"] = "Your cart is empty. Please add items before checkout.";
                return RedirectToPage("/Cart"); // Redirect to the Cart page
            }
            return Page(); // Render the checkout page
        }

        public IActionResult OnPost()
        {
            // Retrieve the cart again on post
            Cart = SessionService.GetSessionObjectFromJson<List<Item>>(HttpContext.Session, "cart");

            // Validate if the cart is not empty
            if (Cart == null || Cart.Count == 0)
            {
                TempData["Error"] = "Your cart is empty. Cannot proceed with checkout.";
                return RedirectToPage("/Cart"); // Redirect to the Cart page
            }

            // Validate the model state
            if (ModelState.IsValid)
            {
                // Clear the cart from the session after successful checkout
                SessionService.SetSessionObjectAsJson(HttpContext.Session, "cart", null);
                return RedirectToPage("/OrderConfirmation"); // Redirect to the order confirmation page
            }

            return Page(); // If validation fails, return to the same page
        }
    }
}
