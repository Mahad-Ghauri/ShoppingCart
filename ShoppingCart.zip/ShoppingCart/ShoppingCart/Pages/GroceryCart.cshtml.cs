using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ShoppingCart.Data; // Ensure you have the correct using directive
using ShoppingCart.Model; // Ensure you have the correct using directive
using ShoppingCart.Service; // Ensure you have the correct using directive
using System.Collections.Generic;
using System.Linq;

namespace ShoppingCart.Pages
{
    public class GroceryCartModel : PageModel
    {
        public List<Item> Cart { get; set; } // Use the same structure as in CartModel

        public decimal Subtotal { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal GSTAmount { get; set; }
        public decimal Total { get; set; }

        private const double DiscountPercentage = 7.0; // 7% Discount
        private const double GstPercentage = 13.0;      // 13% GST

        public double FinalTotalAmount { get; set; }

        private GroceryProductModel productModel; // Add this field

        public GroceryCartModel()
        {
            productModel = new GroceryProductModel(); // Initialize the product model
        }

        public void OnGet(int? id = null)
        {
            // Load the cart from session
            LoadCart();

            // If an id is provided, add or increase product quantity
            if (id.HasValue)
            {
                AddOrUpdateProduct(id.Value);
                // Save the updated cart to the session
                SessionService.SetSessionObjectAsJson(HttpContext.Session, "groceryCart", Cart);
            }

            CalculateCartTotals(); // Calculate totals after any updates
        }

        private void LoadCart()
        {
            // Load the grocery cart items from the session
            Cart = SessionService.GetSessionObjectFromJson<List<Item>>(HttpContext.Session, "groceryCart") ?? new List<Item>();
        }

        private void AddOrUpdateProduct(int id)
        {
            int index = CheckIfExists(id);

            if (index == -1)
            {
                // Product not in cart, add it
                Cart.Add(new Item()
                {
                    Product = productModel.GetProductById(id), // Use grocery model to get product
                    Quantity = 1
                });
            }
            else
            {
                // Increase quantity if product is already in the cart
                Cart[index].Quantity++;
            }
        }

        private int CheckIfExists(int id)
        {
            // Check if the product is already in the cart
            for (int i = 0; i < Cart.Count; i++)
            {
                if (Cart[i].Product.Id == id)
                {
                    return i; // Return the index if found
                }
            }
            return -1; // Not found
        }

        public void OnGetIncreaseProduct(int id)
        {
            LoadCart();
            int index = CheckIfExists(id);
            if (index != -1)
            {
                Cart[index].Quantity++;
                SessionService.SetSessionObjectAsJson(HttpContext.Session, "groceryCart", Cart);
            }
            CalculateCartTotals();
        }

        public void OnGetDecreaseProduct(int id)
        {
            LoadCart();
            int index = CheckIfExists(id);
            if (index != -1)
            {
                if (Cart[index].Quantity > 1)
                {
                    Cart[index].Quantity--;
                }
                else
                {
                    Cart.RemoveAt(index);
                }
                SessionService.SetSessionObjectAsJson(HttpContext.Session, "groceryCart", Cart);
            }
            CalculateCartTotals();
        }

        public void OnGetRemoveProduct(int id)
        {
            LoadCart();
            int index = CheckIfExists(id);
            if (index != -1)
            {
                Cart.RemoveAt(index);
                SessionService.SetSessionObjectAsJson(HttpContext.Session, "groceryCart", Cart);
            }
            CalculateCartTotals();
        }

        private void CalculateCartTotals()
        {
            // Calculate the subtotal (before discount)
            Subtotal = Cart.Sum(item => item.Quantity * (decimal)item.Product.Price);
            // Calculate the discount amount using the defined constant
            DiscountAmount = Subtotal * (decimal)(DiscountPercentage / 100);
            // Calculate the total after discount
            var discountedTotal = Subtotal - DiscountAmount;
            // Calculate GST (13% of the discounted total) using the defined constant
            GSTAmount = discountedTotal * (decimal)(GstPercentage / 100);
            // Calculate the final total (discounted total + GST)
            Total = discountedTotal + GSTAmount;
        }

        private void CalculateFinalAmount()
        {
            var subtotal = Cart.Sum(x => x.Quantity * x.Product.Price);
            var discountAmount = subtotal * (DiscountPercentage / 100);
            var subtotalAfterDiscount = subtotal - discountAmount;
            var gstAmount = subtotalAfterDiscount * (GstPercentage / 100);
            FinalTotalAmount = subtotalAfterDiscount + gstAmount;
        }
    }
}
