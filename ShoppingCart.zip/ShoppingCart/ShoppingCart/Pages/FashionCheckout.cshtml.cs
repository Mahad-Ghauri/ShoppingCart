using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ShoppingCart.Model;
using ShoppingCart.Service;

namespace ShoppingCart.Pages
{
    public class FashionCheckoutModel : PageModel
    {
        public List<Item> Cart { get; set; }

        [BindProperty]
        public string Name { get; set; }

        [BindProperty]
        public string Address { get; set; }

        [BindProperty]
        public string PaymentMethod { get; set; }

        public IActionResult OnGet()
        {
            // Retrieve the cart from session
            Cart = SessionService.GetSessionObjectFromJson<List<Item>>(HttpContext.Session, "cart");

            // Check if the cart is empty
            if (Cart == null || Cart.Count == 0)
            {
                TempData["Error"] = "Your cart is empty. Please add items before checkout.";
                return RedirectToPage("/Cart");
            }
            return Page();
        }

        public IActionResult OnPost()
        {
            // Retrieve the cart from session
            Cart = SessionService.GetSessionObjectFromJson<List<Item>>(HttpContext.Session, "cart");

            // Check if the cart is empty
            if (Cart == null || Cart.Count == 0)
            {
                TempData["Error"] = "Your cart is empty. Cannot proceed with checkout.";
                return RedirectToPage("/Cart");
            }

            // Validate the model
            if (ModelState.IsValid)
            {
                // Clear the cart after successful checkout
                SessionService.SetSessionObjectAsJson(HttpContext.Session, "cart", null);
                return RedirectToPage("/OrderConfirmation");
            }

            return Page();
        }
    }
}
