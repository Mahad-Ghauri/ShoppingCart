using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ShoppingCart.Pages
{
    public class OrderConfirmationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
