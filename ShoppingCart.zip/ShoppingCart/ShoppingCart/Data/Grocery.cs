﻿using ShoppingCart.Model;

namespace ShoppingCart.Data
{
    public class GroceryProductModel
    {
        private List<Product> Products;

        public GroceryProductModel()
        {
            Products = new List<Product>()
            {
                new Product
                {
                    Id = 1,
                    Name = "Chia Seeds",
                    Price = 60,
                    Image = "/Grocery/1.jpg"
                },
                new Product
                {
                    Id = 2,
                    Name = "Kimchi",
                    Price = 25,
                    Image = "/Grocery/2.jpg"
                },
                new Product
                {
                    Id = 3,
                    Name = "Wheat Flour 200gm",
                    Price = 200,
                    Image = "/Grocery/3.jpg"
                },
                new Product
                {
                    Id = 4,
                    Name = "Eggs",
                    Price = 20,
                    Image = "/Grocery/4.jpg"
                },
                new Product
                {
                    Id = 5,
                    Name = "Italian Bread",
                    Price = 700,
                    Image = "/Grocery/5.jpg"
                },
                new Product
                {
                    Id = 6,
                    Name = "Rice 1-kg",
                    Price = 150,
                    Image = "/Grocery/6.jpg"
                },
                new Product
                {
                    Id = 7,
                    Name = "Buldak Ramen Noodles",
                    Price = 15,
                    Image = "/Grocery/7.jpg"
                },
                new Product
                {
                    Id = 8,
                    Name = "National Kofta Masala",
                    Price = 5,
                    Image = "/Grocery/8.jpg"
                },
                new Product
                {
                    Id = 9,
                    Name = "National Sindhi Biryani Masala",
                    Price = 5,
                    Image = "/Grocery/9.jpg"
                },
                new Product
                {
                    Id = 10,
                    Name = "Salted Roasted Cashew 100gm",
                    Price = 25,
                    Image = "/Grocery/10.jpg"
                },
                new Product
                {
                    Id = 11,
                    Name = "Himalayan Pink Salt 200gm",
                    Price = 299,
                    Image = "/Grocery/11.jpg"
                },
                new Product
                {
                    Id = 12,
                    Name = "Tapal Danedar Tea Bags",
                    Price = 30,
                    Image = "/Grocery/12.jpg"
                },

            };
        } // Scope end of Constructor

        public List<Product> GetProducts() // This function is used to return all the products
        {
            return Products;
        }

        public Product GetProductById(int id) // This function is used to return individual products rather than returning all products
        {
            var productById = Products.Where(x => x.Id == id).FirstOrDefault();
            return productById;
        }
    }
}

