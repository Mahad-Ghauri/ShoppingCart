﻿using ShoppingCart.Model;

namespace ShoppingCart.Data
{
    public class FashionProductModel
    {
        private List<Product> Products;

        public FashionProductModel()
        {
            Products = new List<Product>()
            {
                new Product
                {
                    Id = 1,
                    Name = "White top & Baggy jeans",
                    Price = 1550,
                    Image = "/Fashion/1.jpg"
                },
                new Product
                {
                    Id = 2,
                    Name = "Oversized Tee & Baggy Jeans",
                    Price = 1099,
                    Image = "/Fashion/2.jpg"
                },
                new Product
                {
                    Id = 3,
                    Name = "Brown Sandals",
                    Price = 350,
                    Image = "/Fashion/3.jpg"
                },
                new Product
                {
                    Id = 4,
                    Name = "Brown Formal Men Shoes",
                    Price = 599,
                    Image = "/Fashion/4.jpg"
                },
                new Product
                {
                    Id = 5,
                    Name = "Red Sandals",
                    Price = 700,
                    Image = "/Fashion/5.jpg"
                },
                new Product
                {
                    Id = 6,
                    Name = "Baggy jeans",
                    Price = 499,
                    Image = "/Fashion/6.jpg"
                },
                new Product
                {
                    Id = 7,
                    Name = "Jacket",
                    Price = 1299,
                    Image = "/Fashion/7.jpg"
                },
                new Product
                {
                    Id = 8,
                    Name = "Knitted White Tee",
                    Price = 790,
                    Image = "/Fashion/8.jpg"
                },
                new Product
                {
                    Id = 9,
                    Name = "Blue T-Shirt",
                    Price = 250,
                    Image = "/Fashion/9.jpg"
                },
                new Product
                {
                    Id = 10,
                    Name = "Brown Knitted T-Shirt",
                    Price = 799,
                    Image = "/Fashion/10.jpg"
                },
                new Product
                {
                    Id = 11,
                    Name = "Rolex Oyester Perpetual ",
                    Price = 235000,
                    Image = "/Fashion/11.jpg"
                },
                new Product
                {
                    Id = 12,
                    Name = "Casio Virade",
                    Price = 210000,
                    Image = "/Fashion/12.jpg"
                },

            };
        }

        public List<Product> GetProducts() // This function is used to return all the products
        {
            return Products;
        }

        public Product GetProductById(int id) // This function is used to return individual products rather than returning all products
        {
            var productById = Products.Where(x => x.Id == id).FirstOrDefault();
            return productById;
        }
    }
}
